---
name: orange-check-extract
description: "문서(docx·pdf·hwp·hwpx)에서 인용을 전수 추출해 citations.json으로 만든다. 본문뿐 아니라 각주·미주·하이퍼링크까지 빠짐없이 훑어 \"본문 주장 ↔ 인용 출처\" 쌍으로 정리한다. 인용 목록 뽑기, 참고문헌 정리, 각주 추출 요청에 쓴다."
license: MIT
metadata:
  runtime-profile: codex
  suite: orange-check
  contract: refver-report/1.0
---

# Orange Check — 인용 수집

검증 파이프라인의 입구. **여기서 놓친 인용은 뒤의 어떤 단계도 검증하지 못한다.**
그래서 이 스킬의 목표는 판정이 아니라 **누락 0건**이다.

> 실행 환경: **OpenAI Codex (CLI · IDE · 클라우드)**

---

## 0단계 — 인용 전수 수집

여기서 놓친 인용은 영원히 검증되지 않는다. 참고문헌 목록만 보면 안 된다. 실제 문서에서
인용의 상당수는 **각주·미주에만** 있고 목록에는 없다.

```bash
python3 scripts -m refver read <문서> --summary   # 본문·각주·미주 건수 확인
python3 scripts -m refver read <문서>             # 전수 추출
```

지원 형식: `.docx` `.pdf` `.hwp` `.hwpx` `.txt` `.md`.
한글 문서는 의존성 없이 읽는다. HWPX는 각주·미주까지 분리되고, HWP 5.x 이진 파일은
본문이 온전히 나오되 각주 귀속은 근사다. 각주가 중요한 HWP라면 HWPX로 저장하거나
`rhwp`가 있으면 `read --via-pdf`로 PDF를 거쳐 쪽·행까지 얻는다.

수집한 뒤 할 일.

- 인용마다 **"본문 주장 ↔ 인용 출처"** 쌍으로 정리하고 번호를 매긴다.
- 번호는 1단계와 2단계가 **같은 번호**를 쓴다. 본문 등장 위치는 별도 칸에 적는다.
- `claim`에는 문서의 문장을 **그대로 옮긴다.** 요약하지 않는다 — 나중에 대조가 불가능해진다.
- 기관 내부 자료(제공받은 PPT·원자료 등)는 외부 검증 대상에서 빼되 "내부 자료로 분류"라고 명시한다.

---

## 참고 문서

- `references/ref-report-contract.md` — 리포트 계약 (report.json)

## 산출물

`citations.json` — 리포트 계약의 `citations` 배열과 같은 모양이되 `stage1`·`stage2`는 비운다.

```json
{"schema_version": "refver-report/1.0",
 "document": {"filename": "제안서.docx", "format": "docx"},
 "citations": [{"id": "C01", "claim": "문서의 문장 그대로", "doc_locator": "footnote:3",
                "cited_source": {"authors": "", "year": "", "title": ""}}]}
```

## 스스로 점검할 것

- 각주·미주에만 있는 인용을 넣었는가? 참고문헌 목록만 보면 반드시 놓친다
- `claim`이 문서의 문장 그대로인가? 요약했다면 다시 옮긴다
- 같은 출처를 여러 번 인용했다면 **주장마다** 따로 번호를 매겼는가
- 추출 건수가 문서의 각주·미주 개수와 맞는가
